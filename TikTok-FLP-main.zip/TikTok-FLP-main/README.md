<img width="150px" src="https://avatars.githubusercontent.com/u/40530012?v=4" align="right" />

# Tik Tok Followers Landing Page [![Re-skinning](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)](https://re-skinning.com)
> By Mohammed Cha & Re-Skinning Grp


Tik Tok FLP is a Perfect landing page coded in HTML, PHP, JS, and CSS, provided free of charge by Re-skinning Group

Tik Tok Followers Landing Page is an ideal landing page that can pull and show user data, which makes it characterized by a very high conversion rate


## How to !

You can change your CPA link by opening the <code>processing_request.php</code> file with any text editor, change the link in the first line


## DEMO

<img src="https://i.imgur.com/SBHXleM.png"/>
